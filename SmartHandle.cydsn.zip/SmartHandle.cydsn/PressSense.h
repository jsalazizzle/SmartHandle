#ifndef PRESSSENSE_H
#define PRESSSENSE_H

//-----------------------------------------//

#include <project.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

//-----------------------------------------//

void PressSense_Init();
static void Press1Handler();

//-----------------------------------------//

#endif /* PRESSSENSE_H */