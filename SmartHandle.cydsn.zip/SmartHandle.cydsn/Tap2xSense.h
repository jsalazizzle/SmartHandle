#ifndef TAP2XSENSE_H
#define TAP2XSENSE_H

//-----------------------------------------//

#include <project.h>
#include <stdbool.h>

//-----------------------------------------//

void Tap2xSense_Init();

//-----------------------------------------//

#endif /* TAP2XSENSE_H */
