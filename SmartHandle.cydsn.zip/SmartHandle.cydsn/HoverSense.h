#ifndef HOVERSENSE_H
#define HOVERSENSE_H

//-----------------------------------------//

#include <project.h>
#include <stdbool.h>

//-----------------------------------------//

void HoverSense_Init();
void HoverSense_Tick();

//-----------------------------------------//

#endif /* HOVERSENSE_H */
