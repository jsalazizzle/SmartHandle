
#include "project.h"
#include <KinOS.h>

#include "debug.h"

int main(void)
{
    KinOS_Boot();
}
