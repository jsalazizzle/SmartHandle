#ifndef SHAKESENSE_H
#define SHAKESENSE_H

//-----------------------------------------//

#include <project.h>
#include <stdbool.h>

//-----------------------------------------//

void ShakeSense_Init();

//-----------------------------------------//

#endif /* SHAKESENSE_H */
