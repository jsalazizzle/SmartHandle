#ifndef USAGEREPORTSERVICE_H
#define USAGEREPORTSERVICE_H

#include <project.h>
#include <stdbool.h>
   
//-----------------------------------------//

void UseProfileService_Send(void);
void UseProfileService_Handler(void);
    
//-----------------------------------------//

#endif /* USAGEREPORTSERVICE_H */
