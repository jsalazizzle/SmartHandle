#ifndef POWERMONITOR_H
#define POWERMONITOR_H

//-------------------------------------------------------------//

#include <project.h>
#include <stdbool.h>
    
//-------------------------------------------------------------//

void PowerMonitor_Init();
void PowerMonitor_Tick();

//-------------------------------------------------------------//

#endif /* POWERMONITOR_H */
