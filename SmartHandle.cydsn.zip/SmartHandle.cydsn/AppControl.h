#ifndef APPCONTROL_H
#define APPCONTROL_H

//----------------------------------------//

#include <project.h>
#include <stdbool.h>
#include <stdlib.h>

//----------------------------------------//

void AppControlHandler();

//----------------------------------------//

#endif /* APPCONTROL_H */